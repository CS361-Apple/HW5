For LightVC documentation see the local copy in modules/lightvc/README.md or the version for the current release at [the website](http://lightvc.org/).
