Elements
========

Elements are shared pieces of view logic that can be invoked from other controller views, elements, and layouts.

Elements are really just [views](../views.md).
